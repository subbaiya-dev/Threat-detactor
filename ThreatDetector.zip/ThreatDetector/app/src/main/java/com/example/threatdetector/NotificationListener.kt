package com.example.threatdetector

import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import android.util.Patterns
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import java.util.regex.Matcher

class NotificationListener : NotificationListenerService() {

    companion object {
        const val WHATSAPP_PACKAGE_NAME = "com.whatsapp"
        const val NOTIFICATION_INTENT_ACTION = "com.example.threatdetector.NOTIFICATION_LISTENER"
        const val EXTRA_TITLE = "notification_title"
        const val EXTRA_TEXT = "notification_text"
        const val EXTRA_URL = "notification_url"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn?.packageName.equals(WHATSAPP_PACKAGE_NAME)) {
            val notification = sbn?.notification
            val extras = notification?.extras

            val title = extras?.getString("android.title")
            val text = extras?.getCharSequence("android.text")?.toString()

            if (!title.isNullOrEmpty() && !text.isNullOrEmpty()) {
                Log.d("ThreatDetector", "WhatsApp Notification: $title - $text")

                val url = extractUrl(text)

                val intent = Intent(NOTIFICATION_INTENT_ACTION)
                intent.putExtra(EXTRA_TITLE, title)
                intent.putExtra(EXTRA_TEXT, text)
                if (url != null) {
                    intent.putExtra(EXTRA_URL, url)
                }
                // Use LocalBroadcastManager for a more secure and reliable delivery
                LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
            }
        }
    }

    private fun extractUrl(text: String): String? {
        val matcher: Matcher = Patterns.WEB_URL.matcher(text)
        return if (matcher.find()) {
            matcher.group()
        } else {
            null
        }
    }
}