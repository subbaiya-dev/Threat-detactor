package com.example.threatdetector

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.threatdetector.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

// Data class to represent a single threat event
data class Threat(val type: String, val source: String, val action: String)

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val threatsList = ArrayList<Threat>()
    private lateinit var adapter: ThreatAdapter
    private lateinit var notificationReceiver: BroadcastReceiver

    companion object {
        private const val NOTIFICATION_CHANNEL_ID = "ThreatDetectorChannel"
        // IMPORTANT: Replace this with your own API key from the Google Cloud Console
        private const val SAFE_BROWSING_API_KEY = "AIzaSyBRVep0A6ar1HeBHYxbq5wID2voxO2_D7U"
    }

    // Activity result launcher for notification permission
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Log.d("ThreatDetector", "Notification permission granted.")
        } else {
            Log.d("ThreatDetector", "Notification permission denied.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Create notification channel and request permission
        createNotificationChannel()
        requestNotificationPermission()

        // Initial setup
        adapter = ThreatAdapter(this, threatsList)
        binding.threatsListView.adapter = adapter
        updateSummaryCards()

        // Setup button to open notification settings
        binding.permissionButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        // Setup receiver to get data from NotificationListener service
        notificationReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val title = intent?.getStringExtra(NotificationListener.EXTRA_TITLE)
                val text = intent?.getStringExtra(NotificationListener.EXTRA_TEXT)
                val url = intent?.getStringExtra(NotificationListener.EXTRA_URL)

                if (title != null && text != null) {
                    handleNewNotification(title, text, url)
                }
            }
        }

        // Register the LocalBroadcastManager to receive messages from the service
        LocalBroadcastManager.getInstance(this).registerReceiver(notificationReceiver, IntentFilter(NotificationListener.NOTIFICATION_INTENT_ACTION))
    }

    override fun onResume() {
        super.onResume()
        // Update button visibility based on permission status
        if (isNotificationServiceEnabled()) {
            binding.permissionButton.visibility = View.GONE
        } else {
            binding.permissionButton.visibility = View.VISIBLE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(notificationReceiver)
    }

    private fun handleNewNotification(sender: String, message: String, url: String?) {
        if (url != null) {
            // Use coroutine to perform network request on a background thread
            lifecycleScope.launch {
                val isMalicious = isUrlMalicious(url)
                if (isMalicious) {
                    val newThreat = Threat("Suspicious Link", url, "Blocked")
                    addThreat(newThreat)
                    sendThreatNotification(newThreat)
                }
            }
        }
        // The 'else' block that created "Phishing" threats for every message has been removed.
    }

    private suspend fun isUrlMalicious(urlToCheck: String): Boolean = withContext(Dispatchers.IO) {
        val apiUrl = "https://safebrowsing.googleapis.com/v4/threatMatches:find?key=$SAFE_BROWSING_API_KEY"
        try {
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true

            // Create the JSON request body
            val jsonBody = JSONObject()
            val threatInfo = JSONObject()
            val threatTypes = JSONArray(listOf("MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"))
            val platformTypes = JSONArray(listOf("ANY_PLATFORM"))

            val threatEntry = JSONObject()
            threatEntry.put("url", urlToCheck)
            val threatEntries = JSONArray(listOf(threatEntry))

            threatInfo.put("threatTypes", threatTypes)
            threatInfo.put("platformTypes", platformTypes)
            threatInfo.put("threatEntries", threatEntries)
            jsonBody.put("threatInfo", threatInfo)

            // Write the body to the connection
            connection.outputStream.use { os ->
                val input = jsonBody.toString().toByteArray(Charsets.UTF_8)
                os.write(input, 0, input.size)
            }

            // Read the response
            val reader = BufferedReader(InputStreamReader(connection.inputStream))
            val response = reader.readText()
            reader.close()
            connection.disconnect()

            // If the response contains "matches", the URL is malicious.
            // An empty response {} means the URL is safe.
            val jsonResponse = JSONObject(response)
            return@withContext jsonResponse.has("matches")

        } catch (e: Exception) {
            Log.e("ThreatDetector", "Error checking URL: ${e.message}")
            return@withContext false
        }
    }

    private fun addThreat(threat: Threat) {
        runOnUiThread {
            threatsList.add(0, threat)
            adapter.notifyDataSetChanged()
            updateSummaryCards()
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.threat_notification_channel_name)
            val descriptionText = getString(R.string.threat_notification_channel_description)
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun sendThreatNotification(threat: Threat) {
        val builder = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bug) // Use a relevant icon
            .setContentTitle("Threat Detected!")
            .setContentText("Blocked malicious link: ${threat.source}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            with(NotificationManagerCompat.from(this)) {
                notify(System.currentTimeMillis().toInt(), builder.build())
            }
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val enabledPackageNames = NotificationManagerCompat.getEnabledListenerPackages(this)
        return enabledPackageNames.contains(packageName)
    }

    private fun updateSummaryCards() {
        binding.totalThreatsCount.text = threatsList.size.toString()
        binding.malwareCount.text = threatsList.count { it.type == "Malware" || it.type == "Adware" || it.type == "Spyware" }.toString()
        binding.phishingCount.text = threatsList.count { it.type == "Phishing" }.toString()
        binding.badLinksCount.text = threatsList.count { it.type == "Suspicious Link" }.toString()
    }
}

// This custom adapter class is now updated to handle icons.
class ThreatAdapter(context: Context, threats: List<Threat>) :
    ArrayAdapter<Threat>(context, 0, threats) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.list_item_threat, parent, false)

        val threat = getItem(position)

        val text1 = view.findViewById<TextView>(R.id.text1)
        val text2 = view.findViewById<TextView>(R.id.text2)
        val statusIndicator = view.findViewById<TextView>(R.id.status_indicator)
        val threatIcon = view.findViewById<ImageView>(R.id.threat_icon)

        if (threat != null) {
            text1.text = threat.type
            text2.text = context.getString(R.string.source_label, threat.source)
            statusIndicator.text = threat.action.uppercase()

            // Set Icon based on threat type
            val iconRes = when (threat.type) {
                "Malware", "Adware", "Spyware" -> R.drawable.ic_bug
                "Phishing" -> R.drawable.ic_phishing
                "Suspicious Link" -> R.drawable.ic_link_off
                else -> R.drawable.ic_bug // Default icon
            }
            threatIcon.setImageResource(iconRes)

            // Set color for status indicator
            val statusColor = when (threat.action) {
                "Blocked" -> ContextCompat.getColor(context, android.R.color.holo_red_dark)
                "Warned" -> ContextCompat.getColor(context, android.R.color.holo_purple)
                "Quarantined" -> ContextCompat.getColor(context,  android.R.color.holo_orange_dark)
                "Removed" -> ContextCompat.getColor(context, android.R.color.holo_green_dark)
                else -> ContextCompat.getColor(context, android.R.color.darker_gray)
            }
            (statusIndicator.background as GradientDrawable).setColor(statusColor)
        }

        return view
    }
}